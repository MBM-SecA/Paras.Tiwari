public class AcessModifier{
   internal void DoSomething()
    {

    }
    public void DoAnotherThing()
    {

    }

}

class ModifierDemo{
    void Dosomething()
    {
        Person person = new Person();
        person.Age = 34;

    }
}