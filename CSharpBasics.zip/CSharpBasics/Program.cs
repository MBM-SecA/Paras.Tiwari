﻿using  Collections;
using System;
  class Program
    {        static void Main()
        {
          Square square = new Square(34.5);
          square.Display();
          Rectangle rectangle = new Rectangle(45.4,23.5);
          rectangle.Display();
          Circle circle = new Circle(45.4);
          circle.Display();
     
        } 
    


    }

